import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [signals, setSignals] = useState<string[]>([]);
  useEffect(() => {
    axios.get("/api/screener/bullish?tickers=AAPL,TSLA,MSFT").then(res => {
      setSignals(res.data.bullish);
    });
  }, []);
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Bullish Stocks</h1>
      <ul>{signals.map(ticker => <li key={ticker}>{ticker}</li>)}</ul>
    </div>
  );
}
export default App;
