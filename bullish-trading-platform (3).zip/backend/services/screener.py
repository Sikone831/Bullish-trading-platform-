import yfinance as yf
import pandas_ta as ta

def is_bullish(df):
    df['RSI'] = ta.rsi(df['Close'], length=14)
    macd = ta.macd(df['Close'])
    df = df.join(macd)
    return (
        df['RSI'].iloc[-1] > 30 and
        df['MACD_12_26_9'].iloc[-1] > df['MACDs_12_26_9'].iloc[-1] and
        df['MACD_12_26_9'].iloc[-2] <= df['MACDs_12_26_9'].iloc[-2]
    )

def find_bullish_stocks(tickers):
    bullish = []
    for ticker in tickers:
        df = yf.download(ticker, period="3mo", interval="1d")
        if not df.empty and is_bullish(df):
            bullish.append(ticker)
    return bullish
