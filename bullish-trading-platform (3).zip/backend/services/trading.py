from config import ALPACA_KEY, ALPACA_SECRET
import alpaca_trade_api as tradeapi

api = tradeapi.REST(ALPACA_KEY, ALPACA_SECRET, base_url='https://paper-api.alpaca.markets')

def place_order_alpaca(symbol: str, qty: int):
    try:
        api.submit_order(symbol=symbol, qty=qty, side='buy', type='market', time_in_force='gtc')
        return "submitted"
    except Exception as e:
        return str(e)
