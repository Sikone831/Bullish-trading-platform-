from fastapi import APIRouter
from config import PLAID_CLIENT_ID, PLAID_SECRET, PLAID_ENV
from plaid import Client

router = APIRouter(prefix="/plaid")

client = Client(client_id=PLAID_CLIENT_ID, secret=PLAID_SECRET, environment=PLAID_ENV)

@router.get("/link-token")
def create_link_token():
    response = client.LinkToken.create({
        'user': {'client_user_id': 'user-123'},
        'client_name': 'Bullish Trading App',
        'products': ['auth', 'transactions'],
        'country_codes': ['US'],
        'language': 'en'
    })
    return {"link_token": response['link_token']}
