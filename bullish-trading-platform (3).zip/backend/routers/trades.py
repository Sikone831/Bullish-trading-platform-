from fastapi import APIRouter
from services.trading import place_order_alpaca

router = APIRouter(prefix="/trade")

@router.post("/buy")
def buy_stock(ticker: str, qty: int):
    result = place_order_alpaca(ticker, qty)
    return {"status": result}
