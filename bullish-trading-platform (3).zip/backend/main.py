from fastapi import FastAPI
from routers import screener, trades, plaid

app = FastAPI()
app.include_router(screener.router)
app.include_router(trades.router)
app.include_router(plaid.router)
